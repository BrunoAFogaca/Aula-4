# Aula 4 
## Teste de Dick-Fuller
Variações do Valor Crítico - Séries estacionárias ou Não estacionárias
(none, drift e trend)
